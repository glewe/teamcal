<?php

/* ============================================================================
 * PHPINFO.PHP
 * ----------------------------------------------------------------------------
 * Application: TeamCal
 * Author:      George Lewe
 * Copyright:   (c) 2004-2009 by George Lewe (www.lewe.com)
 *              All rights reserved.
 * ----------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the 
 * Free Software Foundation. A copy has been distributed with TeamCal Pro
 * named gpl.txt.
 * 
 * This program is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License 
 * for more details (http://www.gnu.org)
 * ============================================================================
 */

   phpinfo();
?>
