<?PHP
// You are asked not to alter or remove this line. Giving credits is a matter of good manners.
echo "<!-- Created by " . $tc_config['app_name'] . " " . $tc_config['app_version'] . " " . $tc_config['app_copyright'] . " (http://www.lewe.com/teamcal) -->";
?>    

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
   <title>Lewe Team Calendar</title>
   <meta http-equiv="Content-type" content="text/html;charset=iso-8859-1">
   <link rel="stylesheet" type="text/css" href="css/teamcal.css">
   <script type="text/javascript" language="JavaScript" src="js/teamcal.js"></script>
</head>

