    <!-- includes/header.application.inc.php -->
    <table class="header">
        <tr>
            <td class="header-left"><img src="img/logo.gif" width="180" height="55" alt=""></td>
            <td class="header-right"></td>
        </tr>
        <tr>
            <td class="header-subtitle" colspan="2"><?php echo $tc_config['app_subtitle']; ?></td>
        </tr>
    </table>

