    <?php    
       include_once ("includes/config.teamcal.php");
    ?>    
    <hr size="1">
    <div align="center">
        <span class="copyright">
            <?php echo $tc_config['app_footer_cpy']; ?><br>
            <?php echo $tc_config['app_footer_pwd']; ?><br>
            <img src="img/valid-html401.gif" alt="">&nbsp;<img src="img/valid-css.gif" alt="">
        </span>
    </div>
</body>
</html>

